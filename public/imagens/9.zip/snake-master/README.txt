express --view=ejs myapp

npm install nodemon
npm install mysql

"scripts": {
    "start": "node ./bin/www",
    "dev": "nodemon ./bin/www"
},

npm run dev


criar os diretórios
* config
    config/database.config.js
* models
    models/funcionario.model.js
* controllers
    controllers/funcionario.controller.js
* routes
    routes/funcionario.routes.js

ajustar as consts no app

Thunder Client

meu-banner/
│
├── index.html         (arquivo HTML)
├── style.css          (arquivo CSS)
└── imagens/
    ├── imagem1.jpg
    ├── imagem2.jpg
    ├── imagem3.jpg
    └── imagem4.jpg
