localhost:
Emissor: http://localhost:3000/emissor.html

Receptor: http://localhost:3000/receptor.html

npm init -y

npm install express ws

node server.js



online:
 3. Deploy no Render.com
Acesse: https://render.com

Clique em “New → Web Service”

Escolha seu repositório recebe-websocket

Preencha:

Build Command: npm install

Start Command: npm start

Root Directory: (deixe em branco se server.js está na raiz)

Clique em "Create Web Service"

👉 https://envio-nife.onrender.com/emissor.html

👉 https://envio-nife.onrender.com/receptor.html